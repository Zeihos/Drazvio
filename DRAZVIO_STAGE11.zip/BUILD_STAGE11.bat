@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "LOG=DRAZVIO_stage11_compile_log.txt"
set "SOURCE=gamemodes\mod05.pwn"
set "TEMP=gamemodes\mod05.stage11.amx"
set "TARGET=gamemodes\mod05.amx"
set "BACKUP=gamemodes\mod05.amx.before_stage11"
>"%LOG%" echo DRAZVIO Stage 11 - compiler output
if not exist "pawno\pawncc.exe" goto missing
if not exist "pawno\include\a_samp.inc" goto missing
if not exist "%SOURCE%" goto missing
if exist "%TEMP%" del /q "%TEMP%"
"pawno\pawncc.exe" "%SOURCE%" -i"pawno\include" -o"%TEMP%" -d2 >>"%LOG%" 2>&1
if errorlevel 1 goto failed
if not exist "%TEMP%" goto failed
for %%A in ("%TEMP%") do if %%~zA LSS 100000 goto failed
if exist "%TARGET%" if not exist "%BACKUP%" (
    copy /y "%TARGET%" "%BACKUP%" >nul
    if errorlevel 1 goto failed
)
move /y "%TEMP%" "%TARGET%" >nul
if errorlevel 1 goto failed
>>"%LOG%" echo SUCCESS: Stage 11 AMX compiled and installed.
echo SUCCESS: Stage 11 mod05.amx installed. Check %LOG%.
pause
exit /b 0
:missing
>>"%LOG%" echo FAILED: missing compiler, include or source file.
echo ERROR: Required compiler, include or source file missing.
pause
exit /b 1
:failed
>>"%LOG%" echo FAILED: compilation or deployment failed. Stage 10 AMX was not replaced successfully.
echo ERROR: Stage 11 not installed. Check %LOG%. Do not delete the old AMX.
pause
exit /b 1
